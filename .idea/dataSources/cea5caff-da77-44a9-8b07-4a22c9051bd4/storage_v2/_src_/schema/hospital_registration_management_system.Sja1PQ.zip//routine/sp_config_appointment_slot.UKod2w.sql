create
    definer = root@localhost procedure sp_config_appointment_slot(IN p_doctorId bigint unsigned, IN p_visitDate date,
                                                                  IN p_timeSlot varchar(20), IN p_totalNum int unsigned,
                                                                  OUT p_result varchar(50))
proc_label: BEGIN -- 添加标签
    -- 检查医生是否存在
    IF NOT EXISTS (SELECT 1 FROM doctor WHERE doctorId = p_doctorId) THEN
        SET p_result = '医生不存在，配置失败';
        LEAVE proc_label;
    END IF;
    
    -- 检查该医生该时段是否已配置号源
    IF EXISTS (
        SELECT 1 FROM appointment_slot 
        WHERE doctorId = p_doctorId AND visitDate = p_visitDate AND timeSlot = p_timeSlot
    ) THEN
        SET p_result = '该医生该时段已配置号源，不可重复添加';
        LEAVE proc_label;
    END IF;
    
    -- 插入号源记录（剩余号源初始值=总号源数）
    INSERT INTO appointment_slot (
        doctorId, visitDate, timeSlot, totalNum, remainingNum
    ) VALUES (
        p_doctorId, p_visitDate, p_timeSlot, p_totalNum, p_totalNum
    );
    
    SET p_result = '号源配置成功';
END proc_label;

