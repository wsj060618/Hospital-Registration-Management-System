create
    definer = root@localhost procedure sp_cancel_registration(IN p_registrationNo varchar(30), OUT p_result varchar(50))
proc_label: BEGIN -- 添加标签
    DECLARE v_recordId BIGINT UNSIGNED;
    DECLARE v_slotId BIGINT UNSIGNED;
    DECLARE v_status VARCHAR(10);
    
    -- 检查挂号记录是否存在
    IF NOT EXISTS (SELECT 1 FROM registration_record WHERE registrationNo = p_registrationNo) THEN
        SET p_result = '挂号记录不存在，取消失败';
        LEAVE proc_label;
    END IF;
    
    -- 获取挂号记录信息
    SELECT recordId, slotId, status INTO v_recordId, v_slotId, v_status
    FROM registration_record 
    WHERE registrationNo = p_registrationNo;
    
    -- 检查是否已就诊（已就诊不可取消）
    IF v_status = '已就诊' THEN
        SET p_result = '患者已就诊，不可取消挂号';
        LEAVE proc_label;
    END IF;
    
    -- 检查是否已取消
    IF v_status = '已取消' THEN
        SET p_result = '该挂号已取消，无需重复操作';
        LEAVE proc_label;
    END IF;
    
    -- 更新挂号状态 + 释放号源
    UPDATE registration_record SET status = '已取消' WHERE recordId = v_recordId;
    UPDATE appointment_slot SET remainingNum = remainingNum + 1 WHERE slotId = v_slotId;
    
    SET p_result = '取消挂号成功';
END proc_label;

