create
    definer = root@localhost procedure sp_update_visit_status(IN p_recordId bigint unsigned,
                                                              IN p_doctorId bigint unsigned,
                                                              IN p_visitStatus varchar(10),
                                                              IN p_initialDiagnosis varchar(255),
                                                              OUT p_result varchar(50))
proc_label: BEGIN -- 添加标签
    DECLARE v_doctorId BIGINT UNSIGNED;
    DECLARE v_exist INT;
    
    -- 检查挂号记录是否存在
    IF NOT EXISTS (SELECT 1 FROM registration_record WHERE recordId = p_recordId) THEN
        SET p_result = '挂号记录不存在';
        LEAVE proc_label;
    END IF;
    
    -- 获取挂号记录对应的医生ID（验证权限）
    SELECT a.doctorId INTO v_doctorId
    FROM registration_record r
    JOIN appointment_slot a ON r.slotId = a.slotId
    WHERE r.recordId = p_recordId;
    
    -- 验证医生权限（仅能操作自己的患者）
    IF v_doctorId != p_doctorId THEN
        SET p_result = '无权操作其他医生的患者记录';
        LEAVE proc_label;
    END IF;
    
    -- 检查是否已存在接诊记录
    SELECT COUNT(1) INTO v_exist FROM consult_record WHERE recordId = p_recordId;
    
    -- 新增或更新接诊记录
    IF v_exist = 0 THEN
        INSERT INTO consult_record (
            recordId, doctorId, consultTime, visitStatus, initialDiagnosis
        ) VALUES (
            p_recordId, p_doctorId, NOW(), p_visitStatus, p_initialDiagnosis
        );
    ELSE
        UPDATE consult_record 
        SET visitStatus = p_visitStatus, initialDiagnosis = p_initialDiagnosis, consultTime = NOW()
        WHERE recordId = p_recordId;
    END IF;
    
    -- 同步更新挂号记录状态
    UPDATE registration_record SET status = p_visitStatus WHERE recordId = p_recordId;
    SET p_result = '就诊状态更新成功';
END proc_label;

