create definer = root@localhost view v_doctor_appointment as
select `d`.`doctorId`     AS `doctorId`,
       `d`.`name`         AS `doctorName`,
       `d`.`title`        AS `doctorTitle`,
       `de`.`deptId`      AS `deptId`,
       `de`.`deptName`    AS `deptName`,
       `a`.`slotId`       AS `slotId`,
       `a`.`visitDate`    AS `visitDate`,
       `a`.`timeSlot`     AS `timeSlot`,
       `a`.`totalNum`     AS `totalNum`,
       `a`.`remainingNum` AS `remainingNum`
from ((`hospital_registration_management_system`.`doctor` `d` join `hospital_registration_management_system`.`department` `de`
       on ((`d`.`deptId` = `de`.`deptId`))) join `hospital_registration_management_system`.`appointment_slot` `a`
      on ((`d`.`doctorId` = `a`.`doctorId`)))
order by `a`.`visitDate`, `a`.`timeSlot`;

-- comment on column v_doctor_appointment.doctorId not supported: 医生唯一ID（自增主键）

-- comment on column v_doctor_appointment.doctorName not supported: 医生姓名

-- comment on column v_doctor_appointment.doctorTitle not supported: 医生职称（如：主治医师、主任医师）

-- comment on column v_doctor_appointment.deptId not supported: 科室唯一ID（自增主键）

-- comment on column v_doctor_appointment.deptName not supported: 科室名称（唯一）

-- comment on column v_doctor_appointment.slotId not supported: 号源唯一ID（自增主键）

-- comment on column v_doctor_appointment.visitDate not supported: 出诊日期（格式：YYYY-MM-DD）

-- comment on column v_doctor_appointment.timeSlot not supported: 出诊时段（如：9:00-10:00、14:30-15:30）

-- comment on column v_doctor_appointment.totalNum not supported: 该时段总号源数

-- comment on column v_doctor_appointment.remainingNum not supported: 剩余号源数（实时更新）

