create definer = root@localhost view v_patient_registration as
select `r`.`recordId`         AS `recordId`,
       `r`.`registrationNo`   AS `registrationNo`,
       `r`.`registrationTime` AS `registrationTime`,
       `r`.`status`           AS `registrationStatus`,
       `p`.`patientId`        AS `patientId`,
       `p`.`name`             AS `patientName`,
       `p`.`gender`           AS `gender`,
       `p`.`phone`            AS `patientPhone`,
       `a`.`slotId`           AS `slotId`,
       `a`.`visitDate`        AS `visitDate`,
       `a`.`timeSlot`         AS `timeSlot`,
       `d`.`doctorId`         AS `doctorId`,
       `d`.`name`             AS `doctorName`,
       `de`.`deptName`        AS `deptName`
from ((((`hospital_registration_management_system`.`registration_record` `r` join `hospital_registration_management_system`.`patient` `p`
         on ((`r`.`patientId` = `p`.`patientId`))) join `hospital_registration_management_system`.`appointment_slot` `a`
        on ((`r`.`slotId` = `a`.`slotId`))) join `hospital_registration_management_system`.`doctor` `d`
       on ((`a`.`doctorId` = `d`.`doctorId`))) join `hospital_registration_management_system`.`department` `de`
      on ((`d`.`deptId` = `de`.`deptId`)))
order by `r`.`registrationTime` desc;

-- comment on column v_patient_registration.recordId not supported: 挂号记录唯一ID（自增主键）

-- comment on column v_patient_registration.registrationNo not supported: 挂号单号（唯一，格式：REG+患者ID+时间戳）

-- comment on column v_patient_registration.registrationTime not supported: 挂号时间

-- comment on column v_patient_registration.registrationStatus not supported: 挂号状态（未就诊/已就诊/已取消）

-- comment on column v_patient_registration.patientId not supported: 患者唯一ID（自增主键）

-- comment on column v_patient_registration.patientName not supported: 患者姓名

-- comment on column v_patient_registration.gender not supported: 性别：0-未知，1-男，2-女

-- comment on column v_patient_registration.patientPhone not supported: 联系电话（唯一）

-- comment on column v_patient_registration.slotId not supported: 号源唯一ID（自增主键）

-- comment on column v_patient_registration.visitDate not supported: 出诊日期（格式：YYYY-MM-DD）

-- comment on column v_patient_registration.timeSlot not supported: 出诊时段（如：9:00-10:00、14:30-15:30）

-- comment on column v_patient_registration.doctorId not supported: 医生唯一ID（自增主键）

-- comment on column v_patient_registration.doctorName not supported: 医生姓名

-- comment on column v_patient_registration.deptName not supported: 科室名称（唯一）

