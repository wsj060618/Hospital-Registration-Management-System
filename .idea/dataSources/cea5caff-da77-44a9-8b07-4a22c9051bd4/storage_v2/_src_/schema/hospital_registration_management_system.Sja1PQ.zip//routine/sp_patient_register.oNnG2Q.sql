create
    definer = root@localhost procedure sp_patient_register(IN p_patientId bigint unsigned, IN p_slotId bigint unsigned,
                                                           OUT p_registrationNo varchar(30), OUT p_result varchar(50))
proc_label: BEGIN -- 添加标签：proc_label（用于LEAVE退出）
    DECLARE v_remainingNum INT UNSIGNED;
    DECLARE v_doctorId BIGINT UNSIGNED;
    
    -- 检查号源是否存在
    IF NOT EXISTS (SELECT 1 FROM appointment_slot WHERE slotId = p_slotId) THEN
        SET p_result = '号源不存在，挂号失败';
        LEAVE proc_label; -- 通过标签退出存储过程
    END IF;
    
    -- 获取号源信息（加行锁，避免并发超售）
    SELECT remainingNum, doctorId INTO v_remainingNum, v_doctorId 
    FROM appointment_slot 
    WHERE slotId = p_slotId FOR UPDATE;
    
    -- 检查号源是否充足
    IF v_remainingNum <= 0 THEN
        SET p_result = '号源已售罄，挂号失败';
        LEAVE proc_label;
    END IF;
    
    -- 检查患者是否已挂该号源（排除已取消状态）
    IF EXISTS (
        SELECT 1 FROM registration_record 
        WHERE patientId = p_patientId AND slotId = p_slotId AND status != '已取消'
    ) THEN
        SET p_result = '该号源已挂号，不可重复预约';
        LEAVE proc_label;
    END IF;
    
    -- 生成唯一挂号单号（格式：REG+患者ID+时间戳）
    SET p_registrationNo = CONCAT('REG', p_patientId, UNIX_TIMESTAMP(NOW()));
    
    -- 扣减号源余量
    UPDATE appointment_slot SET remainingNum = remainingNum - 1 WHERE slotId = p_slotId;
    
    -- 插入挂号记录
    INSERT INTO registration_record (
        patientId, slotId, registrationNo, registrationTime, status
    ) VALUES (
        p_patientId, p_slotId, p_registrationNo, NOW(), '未就诊'
    );
    
    SET p_result = '挂号成功';
END proc_label;

