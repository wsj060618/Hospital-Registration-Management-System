create definer = root@localhost view v_consult_detail as
select `c`.`consultId`        AS `consultId`,
       `c`.`consultTime`      AS `consultTime`,
       `c`.`visitStatus`      AS `visitStatus`,
       `c`.`initialDiagnosis` AS `initialDiagnosis`,
       `r`.`registrationNo`   AS `registrationNo`,
       `p`.`patientId`        AS `patientId`,
       `p`.`name`             AS `patientName`,
       `p`.`idCard`           AS `idCard`,
       `d`.`doctorId`         AS `doctorId`,
       `d`.`name`             AS `doctorName`,
       `d`.`title`            AS `doctorTitle`,
       `de`.`deptName`        AS `deptName`
from ((((`hospital_registration_management_system`.`consult_record` `c` join `hospital_registration_management_system`.`registration_record` `r`
         on ((`c`.`recordId` = `r`.`recordId`))) join `hospital_registration_management_system`.`patient` `p`
        on ((`r`.`patientId` = `p`.`patientId`))) join `hospital_registration_management_system`.`doctor` `d`
       on ((`c`.`doctorId` = `d`.`doctorId`))) join `hospital_registration_management_system`.`department` `de`
      on ((`d`.`deptId` = `de`.`deptId`)))
order by `c`.`consultTime` desc;

-- comment on column v_consult_detail.consultId not supported: 接诊记录唯一ID（自增主键）

-- comment on column v_consult_detail.consultTime not supported: 接诊时间

-- comment on column v_consult_detail.visitStatus not supported: 就诊状态（未就诊/已就诊）

-- comment on column v_consult_detail.initialDiagnosis not supported: 初步诊断结果

-- comment on column v_consult_detail.registrationNo not supported: 挂号单号（唯一，格式：REG+患者ID+时间戳）

-- comment on column v_consult_detail.patientId not supported: 患者唯一ID（自增主键）

-- comment on column v_consult_detail.patientName not supported: 患者姓名

-- comment on column v_consult_detail.idCard not supported: 患者身份证号（唯一）

-- comment on column v_consult_detail.doctorId not supported: 医生唯一ID（自增主键）

-- comment on column v_consult_detail.doctorName not supported: 医生姓名

-- comment on column v_consult_detail.doctorTitle not supported: 医生职称（如：主治医师、主任医师）

-- comment on column v_consult_detail.deptName not supported: 科室名称（唯一）

