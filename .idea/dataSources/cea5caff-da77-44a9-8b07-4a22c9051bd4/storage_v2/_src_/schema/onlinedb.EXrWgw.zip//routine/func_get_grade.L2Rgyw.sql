create
    definer = root@localhost function func_get_grade(f_uid int) returns varchar(10) reads sql data
BEGIN
  DECLARE credit INT;
  DECLARE grade VARCHAR(10);
  -- 在这里根据输入的用户id查询积分，将查询到的积分放到credit中
  SELECT IFNULL(ucredit, 0) INTO credit FROM `users` WHERE uid = f_uid;
  -- 根据积分，使用条件分支设置grade 等级
  IF credit >=1000 THEN
    SET grade = '黑金';
  ELSEIF credit >= 500 THEN
    SET  grade = '黄金';
  ELSE 
    SET grade = '普通';
  END IF;
  RETURN grade;
END;

