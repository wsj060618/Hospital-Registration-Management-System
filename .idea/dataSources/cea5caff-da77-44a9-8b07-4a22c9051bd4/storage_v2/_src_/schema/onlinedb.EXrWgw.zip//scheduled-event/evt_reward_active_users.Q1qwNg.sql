create definer = root@localhost event evt_reward_active_users on schedule
    at '2025-11-30 23:36:51'
    on completion preserve
    disable
    do
    BEGIN
    -- 更新当月下单3笔及以上的用户积分（增加1000分）
    UPDATE users u
    SET u.ucredit = u.ucredit + 1000
    WHERE EXISTS (
        SELECT 1
        FROM orders o
        WHERE o.uid = u.uid
          AND YEAR(o.ordertime) = YEAR(NOW())
          AND MONTH(o.ordertime) = MONTH(NOW())
        GROUP BY o.uid
        HAVING COUNT(o.oid) >= 3
    );
END;

