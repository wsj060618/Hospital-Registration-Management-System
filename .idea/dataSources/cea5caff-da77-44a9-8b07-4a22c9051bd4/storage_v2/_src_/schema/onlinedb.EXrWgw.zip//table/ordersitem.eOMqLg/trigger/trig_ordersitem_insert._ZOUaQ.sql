create definer = root@localhost trigger trig_ordersitem_insert
    after insert
    on ordersitem
    for each row
BEGIN
  -- 存储当前商品库存量
  DECLARE current_stock INT DEFAULT 0;
  
  -- 赋值当前商品库存量
  SELECT gquantity INTO current_stock 
  FROM goods 
  WHERE goods.gid = NEW.gid 
  FOR UPDATE;   -- 行级锁，避免并发查询库存时的超卖问题
  
  -- 库存校验与扣减
  IF current_stock >= NEW.inum THEN
    UPDATE goods
    SET gquantity = gquantity - NEW.inum
    WHERE goods.gid = NEW.gid;
  ELSE
    -- 抛出自定义错误
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = '商品库存不足';
  END IF;
END;

