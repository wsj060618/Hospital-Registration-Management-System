create
    definer = root@localhost procedure proc_count_goods_sale(IN p_cid int, OUT p_salecount int)
BEGIN
    SELECT SUM(gsale_qty) INTO p_salecount FROM goods WHERE cid = p_cid;
END;

