create
    definer = root@localhost procedure proc_get_user_orders(IN p_user_id int)
BEGIN
    -- 查询用户订单信息，按下单时间降序排序
    SELECT 
        ocode AS 订单编号,
        oamount AS 订单金额,
        ordertime AS 下单时间
    FROM 
        orders  
    WHERE 
        uid = p_user_id  
    ORDER BY 
        ordertime DESC;
END;

