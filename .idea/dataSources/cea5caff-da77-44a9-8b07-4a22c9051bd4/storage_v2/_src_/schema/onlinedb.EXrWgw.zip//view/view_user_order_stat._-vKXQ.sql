create definer = root@localhost view view_user_order_stat as
select `u`.`uid`                     AS `用户ID`,
       `u`.`uname`                   AS `用户姓名`,
       `u`.`ucity`                   AS `所在城市`,
       count(`o`.`oid`)              AS `订单总数`,
       ifnull(sum(`o`.`oamount`), 0) AS `累计消费金额`
from (`onlinedb`.`users` `u` left join `onlinedb`.`orders` `o` on ((`u`.`uid` = `o`.`uid`)))
group by `u`.`uid`, `u`.`uname`, `u`.`ucity`
order by `累计消费金额` desc;

-- comment on column view_user_order_stat.用户ID not supported: 用户ID

-- comment on column view_user_order_stat.用户姓名 not supported: 姓名

-- comment on column view_user_order_stat.所在城市 not supported: 所在城市

