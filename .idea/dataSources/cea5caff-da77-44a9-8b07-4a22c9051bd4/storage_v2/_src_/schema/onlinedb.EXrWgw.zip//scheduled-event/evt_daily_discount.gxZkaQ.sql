create definer = root@localhost event evt_daily_discount on schedule
    at '2025-11-30 19:24:29'
    on completion preserve
    disable
    do
    BEGIN
    -- 将蔬菜水果类商品（cid=3）价格调整为原价的80%
    UPDATE goods
    SET gprice = gprice * 0.8
    WHERE cid = 3; 
END;

