create definer = root@localhost view view_hot_goods as
select `g`.`gid`       AS `商品ID`,
       `g`.`gcode`     AS `商品编号`,
       `g`.`gname`     AS `商品名称`,
       `c`.`cname`     AS `商品类别名称`,
       `g`.`gprice`    AS `商品价格`,
       `g`.`gsale_qty` AS `销售量`,
       `g`.`gquantity` AS `库存量`
from (`onlinedb`.`goods` `g` join `onlinedb`.`category` `c` on ((`g`.`cid` = `c`.`cid`)))
where (`g`.`gishot` = 1)
order by `g`.`gsale_qty` desc;

-- comment on column view_hot_goods.商品ID not supported: 商品ID

-- comment on column view_hot_goods.商品编号 not supported: 商品编号

-- comment on column view_hot_goods.商品名称 not supported: 商品名

-- comment on column view_hot_goods.商品类别名称 not supported: 类别名称

-- comment on column view_hot_goods.商品价格 not supported: 商品价格

-- comment on column view_hot_goods.销售量 not supported: 销售量

-- comment on column view_hot_goods.库存量 not supported: 库存量

