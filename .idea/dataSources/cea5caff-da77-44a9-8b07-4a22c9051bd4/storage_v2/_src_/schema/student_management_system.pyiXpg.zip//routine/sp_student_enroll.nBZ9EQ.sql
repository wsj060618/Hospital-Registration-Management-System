create
    definer = root@localhost procedure sp_student_enroll(IN p_student_id varchar(12), IN p_course_id varchar(10),
                                                         IN p_teacher_id varchar(10), IN p_semester varchar(15),
                                                         OUT p_result varchar(100))
BEGIN
    DECLARE v_count INT; -- 存储查询到的重复选课记录数
    DECLARE v_teach_exist INT; -- 存储授课安排是否存在

    -- 检查学生是否已在同一学期选过该课程（含同一教师）
    SELECT COUNT(*) INTO v_count
    FROM enrollment
    WHERE student_id = p_student_id 
      AND course_id = p_course_id 
      AND teacher_id = p_teacher_id
      AND semester = p_semester;

    -- 检查该课程-教师-学期的授课安排是否存在
    SELECT COUNT(*) INTO v_teach_exist
    FROM teaching
    WHERE course_id = p_course_id
      AND teacher_id = p_teacher_id
      AND semester = p_semester;

    -- 逻辑判断并返回结果
    IF v_count > 0 THEN
        SET p_result = '失败：该学期已选过此教师的该课程，禁止重复选课';
    ELSEIF v_teach_exist = 0 THEN
        SET p_result = '失败：无对应学期的授课安排，无法选课';
    ELSE
        -- 插入选课记录
        INSERT INTO enrollment (student_id, course_id, teacher_id, semester, enroll_time)
        VALUES (p_student_id, p_course_id, p_teacher_id, p_semester, NOW());
        SET p_result = '选课成功';
    END IF;
END;

