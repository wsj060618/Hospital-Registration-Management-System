create definer = root@localhost view v_student_score as
select `s`.`student_id`        AS `学号`,
       `s`.`name`              AS `姓名`,
       `c`.`class_name`        AS `班级`,
       `co`.`course_name`      AS `课程名称`,
       `co`.`credits`          AS `学分`,
       `e`.`semester`          AS `学期`,
       `e`.`score`             AS `成绩`,
       (case
            when (`e`.`score` is null) then '未录入'
            when (`e`.`score` >= 90) then '优秀'
            when (`e`.`score` >= 80) then '良好'
            when (`e`.`score` >= 70) then '中等'
            when (`e`.`score` >= 60) then '及格'
            else '不及格' end) AS `等级`
from (((`student_management_system`.`student` `s` join `student_management_system`.`class` `c`
        on ((`s`.`class_id` = `c`.`class_id`))) join `student_management_system`.`enrollment` `e`
       on ((`s`.`student_id` = `e`.`student_id`))) join `student_management_system`.`course` `co`
      on ((`e`.`course_id` = `co`.`course_id`)));

-- comment on column v_student_score.学号 not supported: 学生学号

-- comment on column v_student_score.姓名 not supported: 学生姓名

-- comment on column v_student_score.班级 not supported: 班级名称

-- comment on column v_student_score.课程名称 not supported: 课程名称

-- comment on column v_student_score.学分 not supported: 学分

-- comment on column v_student_score.学期 not supported: 选课学期（与授课学期一致）

-- comment on column v_student_score.成绩 not supported: 课程成绩（0-100，未录入为NULL）

