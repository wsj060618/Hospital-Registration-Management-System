create
    definer = root@localhost procedure sp_calculate_avg_score(IN p_student_id varchar(12),
                                                              OUT p_avg_score decimal(5, 2), OUT p_grade varchar(10))
BEGIN
    -- 计算指定学生的平均成绩
    SELECT ROUND(AVG(score), 2) INTO p_avg_score
    FROM enrollment
    WHERE student_id = p_student_id AND score IS NOT NULL;

    -- 根据平均分判断成绩等级
    IF p_avg_score IS NULL THEN
        SET p_grade = '无成绩';
    ELSEIF p_avg_score >= 90 THEN
        SET p_grade = '优秀';
    ELSEIF p_avg_score >= 80 THEN
        SET p_grade = '良好';
    ELSEIF p_avg_score >= 70 THEN
        SET p_grade = '中等';
    ELSEIF p_avg_score >= 60 THEN
        SET p_grade = '及格';
    ELSE
        SET p_grade = '不及格';
    END IF;
END;

