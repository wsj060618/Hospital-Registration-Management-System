create definer = root@localhost view v_student_detail as
select `s`.`student_id`                                 AS `学号`,
       `s`.`name`                                       AS `姓名`,
       `s`.`gender`                                     AS `性别`,
       `s`.`birth_date`                                 AS `出生日期`,
       timestampdiff(YEAR, `s`.`birth_date`, curdate()) AS `年龄`,
       `s`.`phone`                                      AS `联系电话`,
       `s`.`class_id`                                   AS `班级编号`,
       `c`.`class_name`                                 AS `班级名称`,
       `c`.`college`                                    AS `所属学院`
from (`student_management_system`.`student` `s` left join `student_management_system`.`class` `c`
      on ((`s`.`class_id` = `c`.`class_id`)));

-- comment on column v_student_detail.学号 not supported: 学生学号

-- comment on column v_student_detail.姓名 not supported: 学生姓名

-- comment on column v_student_detail.性别 not supported: 性别

-- comment on column v_student_detail.出生日期 not supported: 出生日期（格式：YYYY-MM-DD）

-- comment on column v_student_detail.联系电话 not supported: 联系电话

-- comment on column v_student_detail.班级编号 not supported: 所属班级编号

-- comment on column v_student_detail.班级名称 not supported: 班级名称

-- comment on column v_student_detail.所属学院 not supported: 所属学院

